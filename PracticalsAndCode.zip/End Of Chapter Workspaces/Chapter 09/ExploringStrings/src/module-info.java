/**
 * 
 */
/**
 * @author Matt
 *
 */
module ExploringStrings {
}