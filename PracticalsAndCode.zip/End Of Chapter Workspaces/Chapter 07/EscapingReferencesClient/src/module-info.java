
module EscapingReferencesClient {
	requires EscapingReferences;
}