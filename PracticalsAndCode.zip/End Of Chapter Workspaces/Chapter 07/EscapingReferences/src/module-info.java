
module EscapingReferences {
	exports com.virtualpairprogrammers.escapingreferences.customers;
}