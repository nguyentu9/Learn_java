package main;

public class Main {

	public static void main(String[] args) {
		PrimativesPerformance performance = new PrimativesPerformance();		
		//StringBuilderPerformance performance = new StringBuilderPerformance();
		//BigDecimalPerformance performance = new BigDecimalPerformance();
		//LoopPerformance performance = new LoopPerformance();
		performance.run();
	}
}
