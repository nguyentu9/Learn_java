module CodingPerformance {
	requires java.logging;
}