
module EscapingReferences {
}