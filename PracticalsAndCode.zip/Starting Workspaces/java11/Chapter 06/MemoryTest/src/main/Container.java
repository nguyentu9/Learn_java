package main;

public class Container {
	private String initial = "A";
	
	public String getInitial() {
		return initial;
	}
	
	public void setInitial(String initial) {
		this.initial = initial;
	}
}
